#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 15:47:41 2019

@author: colemanbeggs
"""
import random

numberB=random.random()
numberA=random.random()
print(numberA,numberB)
