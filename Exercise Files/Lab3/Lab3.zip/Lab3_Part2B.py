#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 15:47:13 2019

@author: colemanbeggs
"""

import time
from datetime import date
print ()

today = date.today()
print(today)

datetime.datetime.now().time()
datetime.time()
print(datetime.datetime.now().time())
