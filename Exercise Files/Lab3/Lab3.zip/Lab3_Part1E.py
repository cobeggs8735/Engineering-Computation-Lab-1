#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 20:23:00 2019

@author: colemanbeggs
"""

import math

mph = float(input("Input a value of miles per hour: "))
meter_per_sec = mph * 0.44704

print (mph, "miles per hour =", meter_per_sec, "m/s")