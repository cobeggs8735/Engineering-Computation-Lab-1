#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 15:18:40 2019

@author: colemanbeggs
"""

"""
Twinkle, twinkle, little star,
How I wonder what you are!
Up above the world so high,
Like a diamond in the sky.
Twinkle, twinkle, little star,
How I wonder what you are
"""

twinkle = "Twinkle, twinkle, little star,\n"
wonder = "How I wonder what you are!\n"
above = "Up above the world so high,\n"
diamond = "Like a diamond in the sky.\n"

print (twinkle,wonder,above,diamond,twinkle,wonder)
