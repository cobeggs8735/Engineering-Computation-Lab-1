#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 14:56:02 2019

@author: colemanbeggs
"""

import math

weightPounds = float(input("Input a force value in pounds: ")) #Pounds

weightNewtons = weightPounds * 4.44822 #Newtons

print (weightPounds, "lbs =", weightNewtons, "in Newtons")

