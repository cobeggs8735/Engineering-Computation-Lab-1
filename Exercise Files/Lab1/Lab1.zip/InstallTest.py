#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 17 14:58:15 2019

@author: colemanbeggs
"""

import numpy
import matplotlib
