#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 17 15:26:51 2019

@author: colemanbeggs
"""

from math import *


print("1st hr =",(25%13)/12)
print("2nd hr =", (math.sqrt(4)/tan(pi/4))//1)
print("3rd hr =", math.log10(100)*1.5)
print("4th hr =",(math.sin(math.pi/2)+1)**2)
print("5th hr =", math.log(1, 10) + 5//3+4 * math.exp(0))
print("6th hr =",((math.cos(0) + math.sin(pi/2))+17//4))
print("7th hr =",((3%13)**2)-2)
print("8th hr =",(sqrt(16)+87)-((12*5)-8)-31)
print("9th hr =",((sin(5))/((sin(5))*2))*18)
print("10th hr =",(((pi*8)/(pi*4))*5))
print("11th hr =",(log(1, 10)+5//3+4*exp(0)+((cos(0)+sin(pi/2))+17//4)))
print("12th hr =",12*3-fabs(24))