#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 17 15:58:36 2019

@author: colemanbeggs
"""

import numpy
import matplotlib
import math

print (math.sin(0))
print (math.cos(0))
