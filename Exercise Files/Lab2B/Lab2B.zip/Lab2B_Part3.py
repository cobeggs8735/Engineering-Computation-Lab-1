#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 07:39:57 2019

@author: colemanbeggs
"""

print ()
print ("Coleman Beggs")
print ("ENGR: 102-509")
print ("I'm a world champion robot driver.")

#x = 1
#y = 10
#z = 0
#x = y
#x += 1
#y += x
#y *= x
#z += x
#z += y
#print(z)

#1
print ()
print ("Prints 1")

z = 0
x = 1
z += x
print (z)

#3
print ()
print ("Prints 3")

x = 1
z += x
z += x
print (z)

#11
print ()
print ("Prints 11")

z = 0
y = 10
x = y
x += 1
z += x
print (z)

#28
print ()
print ("Prints 28")

z = 0
x = 1
y = 10
x += 1
y += x
y += x
y *= x
z += y
print (z)

#123
print ()
print ("Prints 123")

z = 0
x = 1
y = 10
y += x
x = y
y *= x
x = y
x += 1
x += 1
z += x
print (z)

#10^32
print ()
print ("Prints 10^32")

z = 0
y = 10
x = y
y *= x
x = y
y *= x
x = y
y *= x
x = y
y *= x
x = y
y *= x
x = y
z += x
print (z)

#4321
print ()
print ("Prints 4321")

z = 0
x = 1
x += 1
y = 10
y += x
x = y
y *= x
x = 1
x += 1
x += 1
x += 1
x += 1
y += x
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
x += 1
y *= x
z += y
print (z)