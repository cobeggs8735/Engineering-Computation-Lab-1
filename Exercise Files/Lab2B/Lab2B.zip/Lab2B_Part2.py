#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 25 08:27:07 2019

@author: colemanbeggs
"""

